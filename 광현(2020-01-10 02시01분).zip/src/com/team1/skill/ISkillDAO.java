package com.team1.skill;

import java.util.ArrayList;

public interface ISkillDAO
{
	public ArrayList<String> lists();
}
