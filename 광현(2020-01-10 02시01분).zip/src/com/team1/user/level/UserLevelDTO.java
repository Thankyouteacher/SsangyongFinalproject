/*
	UserLevelDTO.java
*/

package com.team1.user.level;

public class UserLevelDTO
{
	private int lvId, point;

	public int getLvId()
	{
		return lvId;
	}

	public void setLvId(int lvId)
	{
		this.lvId = lvId;
	}

	public int getPoint()
	{
		return point;
	}

	public void setPoint(int point)
	{
		this.point = point;
	}

}
