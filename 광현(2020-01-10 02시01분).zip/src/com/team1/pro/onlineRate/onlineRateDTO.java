/*
	onlineRateDTO.java
*/

package com.team1.pro.onlineRate;

public class onlineRateDTO
{
	private int oid, onRate;

	public int getOid() {
		return oid;
	}

	public void setOid(int oid) {
		this.oid = oid;
	}

	public int getOnRate() {
		return onRate;
	}

	public void setOnRate(int onRate) {
		this.onRate = onRate;
	}
}