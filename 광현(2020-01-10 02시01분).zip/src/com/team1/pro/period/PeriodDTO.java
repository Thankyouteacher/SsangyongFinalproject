/*
	PeriodDTO.java
*/

package com.team1.pro.period;

public class PeriodDTO
{
	private int proId;
	private String proPeriod;

	public int getProId()
	{
		return proId;
	}

	public String getProPeriod()
	{
		return proPeriod;
	}

	public void setProId(int proId)
	{
		this.proId = proId;
	}

	public void setProPeriod(String proPeriod)
	{
		this.proPeriod = proPeriod;
	}
}