package com.team1.bank;

public class BankDTO
{
	private int bkId;
	private	String bkName;
	
	public int getBkId()
	{
		return bkId;
	}
	public void setBkId(int bkId)
	{
		this.bkId = bkId;
	}
	public String getBkName()
	{
		return bkName;
	}
	public void setBkName(String bkName)
	{
		this.bkName = bkName;
	}
	
	
	
}
